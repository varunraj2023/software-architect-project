from django.apps import AppConfig


class MypollsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mypolls'
